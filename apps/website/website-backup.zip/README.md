# Wortly — German Learner Website (frontend prototype)

A polished, responsive learner-facing website built around the **public endpoints** of the supplied German-learning NestJS API. This is a **new, standalone project**; your existing Admin CMS and API are not modified.

## Review the design without running a server

Open **`preview.html`** in any modern browser. It contains the design and sample A1–C1 learning content so you can click through the pages, try flashcards, and run a quiz offline. **The preview data is fictional and is not pulled from your Admin CMS.**

For a realistic integration check, run the website below and connect your existing API.

## Run the actual website

Requirements: Node.js **18 or later**. No `npm install` or third-party JavaScript packages are needed.

**Mac / Linux**:

```sh
cd german-learner-frontend
API_BASE_URL=http://127.0.0.1:4000/api PORT=3002 npm start
```

**Windows PowerShell**:

```powershell
cd german-learner-frontend
$env:API_BASE_URL="http://127.0.0.1:4000/api"
$env:PORT="3002"
npm start
```

Then open: **http://localhost:3002**

- `API_BASE_URL` = URL of your **NestJS API** including the `/api` prefix, as seen from the machine **running the Node server** (not from the user's browser).
- `PORT` = website port. Use a different port from your current Admin CMS and API.
- All public API requests go through the site's **read-only same-origin proxy** (`/api/...`), so you normally do **not** need additional browser CORS origins.
- If the API is unreachable, the actual website switches to **visibly labeled preview/sample mode** for design review. Click **Retry** when your API becomes available.

## Pages

- `/` — Overview / dashboard and study-level selector (A1–C1)
- `/courses` — Published courses, search, level tabs
- `/courses/:id` — Published modules, curriculum, lesson progress
- `/lessons/:id` — German reading with English and Bangla translations and German text-to-speech
- `/vocabulary` — Published vocabulary with search, category filtering, audio playback and optional media images
- `/flashcards` — Flip cards from published vocabulary
- `/practice` — Multiple-choice mini quizzes generated from published vocabulary
- `/progress` — Progress on this browser (lessons completed, learned words and best quiz score)
- `/about` — About the learning experience

## API mapping

| CMS/API resource | Public endpoint used | How website uses it |
|---|---|---|
| Levels / apps | `GET /api/apps` | Shows active A1–C1 levels |
| Courses | `GET /api/courses` | Shows published courses only |
| Modules | `GET /api/courses/modules` | Shows published modules in published courses only |
| Lessons | `GET /api/courses/lessons` | Shows published lessons in published modules/courses only |
| Vocabulary categories | `GET /api/vocabulary/categories` | Vocabulary category tabs |
| Published vocabulary | `GET /api/vocabulary?appId=<id>` | Vocabulary, audio, flashcards, generated quizzes |

**Important integration limitations:**

1. The uploaded API protects its `/flashcards` and `/quizzes` routes with **admin JWT guards**; therefore this learner website **does not use or expose admin tokens**. Flashcards and mini quizzes are generated locally from public vocabulary. They are **not the same as CMS-authored decks/quizzes**.
2. The uploaded API doesn't expose a public learner sign-in and progress-update flow in the routes used by this prototype. Completed lessons, mastered words, and best quiz scores are saved **only in browser `localStorage`**, not to your database or across devices.
3. The public vocabulary endpoint currently caps results at **100 records per request**. This website will display up to 100 published vocabulary items per level until the API supports pagination.
4. The original API's public courses endpoints may return **unpublished/draft** records. This website's proxy filters drafts and unpublished ancestors before sending course, module or lesson data to the learner's browser. **This does not fix the API's original direct endpoints:** the API should separately enforce published-only public access before production.
5. Any content you publish in the Admin CMS becomes visible in the website after refresh, subject to public API responses.

## Testing

```sh
npm run check
node tests/smoke.mjs
node tests/proxy.mjs
```

## Files

- `src/main.js` — Pages, state, navigation, API data mapping, interactions
- `src/styles.css` — Responsive design system
- `src/demo-data.js` — Clearly labeled **sample content** used only when API cannot be reached
- `server.mjs` — Node static server + public, read-only API proxy
- `index.html` — Actual website entry point
- `preview.html` — Standalone clickable, offline **design preview**, not an API integration
- `assets/favicon.svg` — Placeholder brand icon

**Brand note:** “Wortly” is a temporary name and visual identity for this design proposal. The brand, colors, illustrations, copy, and page layouts can be revised after you review the prototype.
